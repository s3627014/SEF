package errors;

public class InstanceNotFound extends Exception {
	
}
