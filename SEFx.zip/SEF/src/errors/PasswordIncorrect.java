package errors;

public class PasswordIncorrect extends Exception {

}
