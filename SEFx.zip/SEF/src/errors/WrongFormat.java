package errors;

public class WrongFormat extends Exception {

}
