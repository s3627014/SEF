package main;

class Initialise {
	public static void main(String [ ] args) throws Exception {

		LogInFrame.initialise();
	}
}
