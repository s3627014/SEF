package main;

/**
 * Created by luke on 31/03/2017.
 */

public class Admin extends User {
	
   public Admin(String id, String password, String fName, String lName){
        super(id, password, fName, lName);
    }

}
